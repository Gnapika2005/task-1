# DevOps Task 1 – Command Log

pwd
ls
ls -l
cd /
cd ~
mkdir devops-task-1
touch file1.txt file2.txt
mkdir logs scripts
rm file2.txt
rmdir logs
rm -r scripts
cat > file1.txt
ls -l
chmod 755 file1.txt
df -h
free -m
top
